# Agentic AI at Work — Presentation Skeleton
*7 sections · 73 slides · Claude Code & Cowork on the desktop*
*Note: slash commands are Claude Code (terminal / Code tab). The **Env** column in command tables shows where each works: **Code** = Code tab only; **Code · Cowork** = the command is Code, and Cowork has a GUI equivalent (button/menu) for the same action.*

---

## How this deck is organised

**Sections** are collections of slides on one topic. **Slides** are one screen, one idea — numbered `section.slide` (e.g., 3.4 = Section 3, slide 4).

| Section | Topic | Slides |
|---|---|---|
| **1 — Orientation** | Title, interface anatomy, projects | 1.1–1.5 |
| **2 — Framing** | Concept map, Markdown primer, the reframe | 2.1–2.3 |
| **3 — Foundation** | Persistent instructions · Auto memory · Working directory · Agentic loop · Cowork approval · **capstone mission** | 3.x |
| **4 — Agent capabilities** | Skills · Subagents | 4.x |
| **5 — Integration & output** | Connectors · Plugins · Artifacts | 5.x |
| **6 — Automation** | Scheduled tasks · Dynamic workflows | 6.x |
| **7 — Synthesis & close** | Code vs Cowork, governance, one habit, utilities | 7.x |

**Each concept is a mini-section of slides, all in the same order:**
`what it is` → `demo` → (`extras`, if any) → `where it lives` → `do's, don'ts & commands`.

**Reference images:** `screenshot-chat-tab.png` · `screenshot-cowork-tab.png` (both annotated).

---

# Section 1 — Orientation

*Goal: get the team fluent in where things are before introducing any concept.*
---

## 1.1 — Title

**Headline:** The building blocks of agentic AI
**Subline:** Claude Code & Cowork — hands-on for everyday work
**Bottom:** Center name · Date

---

## 1.2 — Interface anatomy: sidebar, tabs & screenshots

**Headline:** Know the interface — where everything lives

*This slide is a labelled orientation tour before any concept is introduced.*

### Reference screenshots (annotated)
- **Chat tab anatomy:** `screenshot-chat-tab.png` — annotated diagram with 12 labelled elements (tabs, + New chat, Projects, Artifacts, account/plan, attachment, model + effort, voice, connector chips, Dispatch)
- **Cowork tab anatomy:** `screenshot-cowork-tab.png` — annotated diagram with 14 labelled elements (adds Scheduled routines, Live artifacts, Dispatch Beta, Work-in-a-project, Ask permission mode)

> Use the Chat screenshot for this slide. The Cowork screenshot belongs on the Code-vs-Cowork slide (and as a reference when introducing Cowork-specific concepts).

### Left sidebar
| Element | What it does |
|---|---|
| **`+` new chat** (pencil / compose icon) | Start a fresh standalone conversation — no prior context, no shared memory |
| **Recent chats** | All standalone conversations — searchable; each is isolated from the others |
| **Projects** | Organised workspaces with shared knowledge + instructions (→ next slide) |
| **Starred / pinned chats** | Quick-access bookmarks for important conversations |
| **Settings** | Memory, Skills, Style preferences, connected apps |

### Claude Desktop — three tabs (top of window)
| Tab | What opens |
|---|---|
| **Chat** | Standard conversation — identical to the web UI |
| **Code** | Claude Code terminal — full agentic coding, CLAUDE.md, skills, subagents |
| **Cowork** | Tasks — agentic knowledge work on your local files (GUI, no terminal) |
---

## 1.3 — Interface anatomy: input bar, artifacts & the three `+` buttons

### Chat window — top bar
| Element | What it does |
|---|---|
| **Model selector** | Switch between Haiku 4.5 · Sonnet 4.6 · Opus 4.8 mid-session |
| **Effort slider** | Control thinking depth — low · medium · high · xhigh · max · auto |

### Chat window — input bar (bottom)
| Element | What it does |
|---|---|
| **`+` / attachment icon** | Upload files, images, PDFs into *this conversation only* |
| **Tools toggle** | Turn web search, code execution, and file creation on/off per session |
| **Voice button** | Push-to-talk dictation |
| **Send** | Submit prompt |

### Artifacts panel (right — opens automatically)
| Element | What it does |
|---|---|
| **Rendered output** | Live preview of HTML, React, SVG, data visualisations |
| **Artifacts sidebar** | All saved artifacts in one browsable place — create, remix, download |
| **Copy / Download** | Export the artifact as a file |

### The three `+` buttons — people often confuse these
| Where | What `+` does |
|---|---|
| Sidebar top | Open a **new standalone chat** |
| Inside a Project (knowledge panel) | **Add files to the project knowledge base** — shared across all project chats |
| Inside a Project chat (input bar) | Upload a file for **this conversation only** — not added to the knowledge base |

---
---

## 1.4 — Projects: what they are

**Headline:** Projects — your persistent workspace

### What a Project is
A self-contained workspace with its own chat history and knowledge base. Three persistent layers that survive across every chat inside the project:

| Layer | What it is | Where it lives |
|---|---|---|
| **Instructions** | How Claude behaves — tone, rules, role, conventions — applied to every chat without consuming the context window | Cloud (claude.ai/projects) |
| **Knowledge base** | Uploaded documents Claude draws on in every chat — PDF, DOCX, CSV, TXT, HTML, XLSX, up to 30 MB per file | Cloud (claude.ai/projects) |
| **Chats** | All conversations in the project — each can access the knowledge base, but chats do **not** share context with each other | Cloud (project history) |

### Key behaviours
- Chats within a project do **not** automatically share context — only the knowledge base is shared.
- Paid plans: Claude auto-enables RAG when the knowledge base grows large, expanding capacity up to 10×.
- Free: 5 projects. Paid (Pro/Max/Team/Enterprise): unlimited + enhanced RAG.
- Team/Enterprise: share projects with org members — **Can use** (read + chat) or **Can edit** (modify instructions, knowledge, members).
---

## 1.5 — Projects: storage, use cases & practice

### File storage
| Component | Where it lives |
|---|---|
| Instructions | Cloud — set via "Set project instructions" in the project panel |
| Knowledge base files | Cloud — uploaded via the `+` button in the project knowledge panel |
| Chat history | Cloud — project conversation list at claude.ai/projects |
| Skills (if set) | Scoped to the project — separate from user-level skills |

### Everyday use cases
| Project | Instructions | Knowledge base |
|---|---|---|
| **Client account** | "Match our brand voice. Always flag risks and open questions." | Contracts, briefs, past deliverables |
| **Team handbook** | "Follow our style guide. Plain language, no jargon." | SOPs, policies, onboarding docs |
| **Proposal writing** | "Formal tone. Map each section to the RFP requirements." | Draft scope, pricing, references |
| **Weekly reporting** | "Structure as: progress / blockers / decisions / next steps." | This week's notes and updates |

---

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| One project per focused task — keep scope tight | Put everything in one giant project — retrieval quality drops |
| Write specific instructions — they persist without using context window | Assume chats inside a project share context — they don't |
| Use descriptive names: "Acme renewal — Q3 2026" | Upload confidential or regulated data — the knowledge base is cloud-stored |
| Replace outdated file versions rather than adding on top | Let the knowledge base grow uncurated — irrelevant files confuse RAG |
| Archive finished projects to keep the sidebar clean | Rely on Projects as your only backup — export important chats periodically |

---
---

# Section 2 — Framing

*Goal: give the mental model and the one file format before the concepts.*
---

## 2.1 — The concept map

**Headline:** The capabilities, in three tiers

*This is the agenda for the rest of the session — what each tier means and what lives in it.*

| Tier | What it means | Capabilities |
|---|---|---|
| **Foundation** | What you set up first — how the agent behaves and what it can touch | Persistent instructions · Auto memory · Working directory · Agentic loop · Cowork approval |
| **Agent capabilities** | How the agent thinks and delegates | Skills · Subagents |
| **Integration & output** | How it reaches outside itself and produces things | Connectors · Plugins · Artifacts |
| **Automation** | Work that runs without you — on a schedule, or fanned across many agents | Scheduled tasks · Dynamic workflows |

*Same engine, different surface: Code tab = terminal, Cowork tab = GUI.*

---
---

## 2.2 — Markdown in 90 seconds

**Headline:** Markdown — the one format everything is built on

Almost everything you configure in Claude lives in a plain-text **Markdown** file. A quick primer here means the `.md` files in every concept ahead aren't a mystery.

### What it is
- A lightweight way to add formatting to plain text using a few simple symbols.
- A `.md` file is *just text* — open it in any editor, readable with or without rendering.
- Claude reads and writes Markdown natively. It's the lingua franca of the whole system.

### Where it shows up in this session
| File | What it is |
|---|---|
| `CLAUDE.md` | Persistent instructions (Slide 3.1) |
| `SKILL.md` | A skill definition (Slide 4.1) |
| `<agent>.md` | A subagent definition (Slide 4.7) |
| Plugin docs | Plugin components (Slide 5.8) |
| Claude's outputs | Reports, summaries, notes — often `.md` |

### Core syntax — the handful you'll actually use
| You type | You get |
|---|---|
| `# Heading` | A large heading |
| `## Subheading` | A smaller heading |
| `**bold**` | **bold** |
| `*italic*` | *italic* |
| `- item` | a bullet list |
| `1. item` | a numbered list |
| `` `code` `` | inline code |
| ` ```code block``` ` | a fenced code block |
| `[text](url)` | a clickable link |
| `> quote` | an indented quote block |

### YAML frontmatter — the one extra bit
At the very top of some files (SKILL.md, agent files) sits a `---` fenced block of `key: value` pairs called **frontmatter**. It's metadata Claude reads first to know what the file is:
```
---
name: doc-summary
description: Use when the user shares a document and wants the team's standard summary.
---
```

### Try it
*Ask Claude:* "Show me this README as rendered output and as raw text side by side."
Seeing both at once makes the format click instantly — the symbols on the left, the formatting on the right.

---
---

## 2.3 — The reframe

**Headline:** Stop prompting. Start delegating.

The shift this whole session is about: you stop typing one message at a time and start handing over an *outcome*. The agent plans it, works on your real files, and you steer — instead of you doing every step yourself.

*Don't define it yet — just plant the idea. By the agentic loop (Slide 3.14) they'll have seen it work, and the full comparison lands there.*

> **Opening demo:** "Organise this folder of 8 PDFs by topic and give me a one-paragraph summary of each."
> Run it live. Don't explain the mechanics — just let them watch Claude plan, touch files, and deliver. That single demo is the hook for everything that follows.

---
---

# Section 3 — Foundation

*What you set up first: how the agent behaves and what it can touch.*
---

## 3.1 — Persistent instructions: what it is

**Tag:** Foundation

**Headline:** CLAUDE.md — the behavioral contract

### Structure
- Plain markdown read at session start
- User-level `~/.claude/CLAUDE.md` — applies to all projects
- Project-level `./CLAUDE.md` — project specifics
- Keep under ~200 lines or adherence degrades
- Cowork equivalent: project context panel (GUI)

### Use case
> Team name, house style, tone, a confidential-data hard stop — written once, applied every session.
---

## 3.2 — Persistent instructions: demo

### Example to cover
**Simulate the agent — a 3-step live demo.**

**Step 1 — Set up the CLAUDE.md (write this silently before the session, ~1 min):**
```
# Acme Co — Marketing Team
Audience: busy execs. Always respond in plain, concise business English.
## Rules
- Lead with the recommendation, then the reasoning.
- Use our terms: "customers" (never "users"), "ARR" (never "revenue run-rate").
- Flag any claim under 80% certainty with [uncertain].
- Never include customer PII or confidential figures in any output.
```

**Step 2 — Give a blank, context-free prompt (nothing about style or rules):**
> *"Write a 3-sentence summary of why our Q3 churn went up."*

**Step 3 — Show what the agent returns:**
> Recommendation: prioritise onboarding fixes — that's where the Q3 churn signal is strongest [uncertain]. Churn among customers rose against Q2, concentrated in accounts under 90 days old, which points to early-lifecycle friction rather than pricing. Tightening the first-month onboarding flow is the lowest-cost lever likely to move ARR retention next quarter.

**Point to the room:** Nobody said "lead with the recommendation" or "flag uncertainty" or "say customers, not users" in the prompt. The CLAUDE.md said it — once, written before the session started. That is the behavioral contract working. Change one rule, every future response changes with it.
---

## 3.3 — Persistent instructions: where it lives

### File structure
```
GLOBAL — applies to every project on this machine
~/.claude/
├── CLAUDE.md ← user-level instructions (always loaded)
└── CLAUDE.local.md ← machine-only overrides (gitignored)

LOCAL — applies to this project only
<project-root>/
├── CLAUDE.md ← project instructions (loaded at session start)
├── CLAUDE.local.md ← machine-specific project overrides (gitignored)
└── .claude/
    └── rules/
        ├── style.md ← path-scoped modular rule (optional)
        └── data-rules.md ← loaded only when Claude reads matching files
```
> Nested `CLAUDE.md` files inside subdirectories are loaded on demand (when Claude reads files in that dir), not at session start. Only the project-root file is re-injected after `/compact`.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✗ | ✓ | ⚠️ | ✗ |
*Code: full CLAUDE.md (user-level + project-level). Cowork: project context panel — same concept, different mechanism, no editable .md file. Web / Chat & Studio: no persistent per-project instructions.*
---

## 3.4 — Persistent instructions: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Keep it under ~200 lines — every line must change behaviour | Dump everything in; it's a contract, not documentation |
| Put the confidential-data hard stop here as the first hard rule | Treat it as a hard wall — CLAUDE.md *instructs*, it doesn't *enforce*; back it with folder permissions |
| Use user-level for personal prefs, project-level for project rules | Mix personal preferences with project-specific rules in one file |
| Update it when conventions change — stale rules cause wrong outputs | Put sensitive data, API keys, or customer records in the file |
| Add a `CLAUDE.local.md` for machine-specific details (auto-gitignored) | Assume it survives `/compact` if it's in a nested subdirectory (only root CLAUDE.md is re-injected) |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/init` | Code · Cowork | Generates a starter CLAUDE.md by analysing your project structure. Set `CLAUDE_CODE_NEW_INIT=1` for an interactive flow that also covers skills, hooks, and memory. |
| `/memory` | Code · Cowork | Open the memory manager — edit CLAUDE.md files, toggle auto memory on/off, view saved entries. |

---
---

## 3.5 — Auto memory: what it is

**Tag:** Foundation

**Headline:** Auto memory — what Claude learns about you

### Structure
- Notes Claude writes for itself from corrections and preferences
- Stored as editable markdown you can view and delete
- Complements CLAUDE.md: you write yours, Claude writes its own
- Builds across sessions without manual effort

### Use case
> Correct it once on date formatting — it applies that automatically next session.
---

## 3.6 — Auto memory: demo

### Example to cover
*Mid-session:* "I always want dates as DD-MMM-YYYY, and amounts in thousands with a k suffix."
→ Close session → Open new session → Ask for a results paragraph → Watch it remembered.
---

## 3.7 — Auto memory: where it lives

### File structure
```
GLOBAL — Claude writes these; you can read and edit them
~/.claude/
└── projects/
    └── <project-hash>/
        └── memory/
            ├── MEMORY.md ← index (200-line cap; capped for performance)
            ├── preferences.md ← style, format preferences
            ├── project-context.md ← discovered facts about the project
            └── reference.md ← pointers to important files/decisions

LOCAL — no local files; all auto memory is written to the global store above
```
> View and edit everything with `/memory`. Deleting a file removes those memories permanently.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ⚠️ | ✓ | ✓ | ✗ |
*Web / Chat: claude.ai conversation memory exists but is cross-conversation, not project-scoped. Code & Cowork: full auto memory per project, viewable with `/memory`. Studio: no memory.*
---

## 3.8 — Auto memory: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Review saved entries with `/memory` periodically — delete stale ones | Assume it will remember everything correctly without checking |
| Correct it immediately when it saves something wrong | Let conflicting memories accumulate across sessions |
| Use it for style and format preferences — it excels at those | Rely on it for compliance-critical rules (use CLAUDE.md for those — it's explicit) |
| Clean out outdated memories at the start of a new project phase | Type confidential data or customer details in corrections — it saves what you correct |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/memory` | Code · Cowork | View all saved memory entries, edit them, or turn auto memory off. Run this to show the room what Claude has learned. |

---
---

## 3.9 — Working directory + permissions: what it is

**Tag:** Foundation

**Headline:** Files & folders — the substrate

### Structure
- Operates inside a sandboxed local VM
- Accesses only the folders you explicitly grant
- Reads uploads, writes to outputs — nothing else
- First guardrail: never grant the folder holding confidential or regulated data

### Use case
> Rename 8 plate-reader CSVs by date + condition, merge into one tidy file, save to /outputs.
---

## 3.10 — Working directory + permissions: demo

### Example to cover
*Grant a demo folder. Prompt:*
"Rename each file to YYYY-MM-DD_condition.csv, merge into combined_results.csv, save to /outputs."
→ Then ask it to read a file outside the granted folder. Watch it refuse.
---

## 3.11 — Working directory + permissions: granting folder access

### How to grant folder access — NOT the `+` button
> ⚠️ This is a common confusion. The `+` buttons from the interface anatomy slide (new chat / add to project / upload file) are **not** how you grant working directory access. Granting folder access is a separate system-level action:

| Surface | How to grant folder access |
|---|---|
| **Code (terminal)** | Run `/add-dir <path>` inside the session, or launch with `claude --add-dir <path>` |
| **Cowork (desktop)** | The app shows a **system folder picker** when it needs access — you approve specific folders via an OS dialog. This is separate from the `+` button in the chat input bar. |
| **Web / Mobile** | No folder access — file upload via the input bar `+` is session-only, not persistent folder access |
---

## 3.12 — Working directory + permissions: where it lives

### File structure
```
GLOBAL — user-level permission defaults
~/.claude/
└── settings.json
    └── "permissions": { "deny": ["/confidential/**"] } ← blocked paths

LOCAL — project-level permission overrides
<project-root>/.claude/
└── settings.json
    └── "permissions": { "allow": ["./data"], "deny": ["./data/raw/private"] }

RUNTIME — directories Claude can read/write during the session
<project-root>/ ← default working directory
├── data/ ← granted read/write (if permitted)
│ └── plate-reader-exports/
└── outputs/ ← Claude writes results here
```
> In Cowork, the OS folder picker — not a config file — controls which folders are granted. There is no `settings.json` to edit in Cowork.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✗ | ✓ | ✓ | ✗ |
*Web / Chat: file upload per session only — no persistent folder access, no write access. Code & Cowork: full granted-folder access in a sandboxed VM. Studio: no file system access.*
---

## 3.13 — Working directory + permissions: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Grant only the specific folders needed for the task at hand | Grant your home directory, root, or any folder containing confidential data |
| Create a dedicated `/outputs` folder — keep raw data and outputs separate | Mix raw data and outputs in the same granted folder |
| Verify what's in a folder before granting access | Forget that it can *write* — review outputs before using them downstream |
| Use `/add-dir` mid-session to extend access incrementally | Grant broad access "just in case" — minimum necessary is the rule |
| Remove folder access after the task is done | Leave a sensitive folder permanently granted across unrelated tasks |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/add-dir <path>` | Code | Grant access to an additional working directory mid-session without restarting. |
| `/context` | Code | Show a visual grid of current context usage — how much each folder and tool is consuming. |

---
---

## 3.14 — The agentic loop: what it is

**Tag:** Foundation

**Headline:** Gather context → act → check → repeat

### The loop is the engine
The agentic loop is how the agent does multi-step work: it gathers context, takes an action, checks the result, and repeats until the task is done. **This runs on both Code and Cowork, in every mode** — it's the thing that makes Claude an agent rather than a chatbot.

What you control is not *whether* there's a loop, but *how much it pauses to check with you.* That's the **permission mode** — a supervision layer on top of the same loop.

### Checkpoint styles — how you supervise the loop
| Mode | What happens | Surface |
|---|---|---|
| **Per-action approval** — Ask (Code) / Ask before acting (Cowork) | The loop pauses before each consequential action; you approve or redirect, then it continues | Both *(default)* |
| **Up-front plan** — Plan mode | The loop maps out the whole approach first; you approve one consolidated plan, then it runs | Code only |
| **No checkpoint** — Auto / Act without asking | The loop runs straight through; no approval prompts | Both |

> **The key idea:** even with no approval prompts (Auto), the loop is still running — you've just removed the human gate. Plan mode isn't "the loop"; it's one way to review it. Per-action Ask is the loop too.

> **Teach this:** start with checkpoints on — per-action Ask, or Plan mode if you're in the Code tab — never Auto, until you trust what the agent does with your files. Cowork's specifics are on slide 3.19.

### Use case
> "Reorganise this folder and write me an index." The loop reads the folder, plans the renames, moves files, writes the index — checking with you along the way. You redirect mid-loop → "copy, don't move the originals" → it adjusts and continues.
---

## 3.15 — The agentic loop: demo (Plan mode, Code)

### Example to cover
**Live walkthrough — Plan mode, in the Code tab.**

*The plan only matters for multi-step, file-touching work — a plain "summarize this" just answers. So give it real work that changes files.*

**Setup:** A messy folder (~10 mixed files, inconsistent names). Enter **Plan mode** — type `/plan` or pick it from the mode selector.

**1. Ask for the outcome:**
> *"Rename every file to `YYYY-MM-DD_description`, sort into subfolders by type, and write an index file."*

**2. Claude shows the full plan and waits** — every step listed, nothing touched yet. *This is where you steer.*

**3. Redirect before approving:**
> *"Don't move the originals — copy them into a new /sorted folder instead."*

**4. Approve the plan.** It exits Plan mode and executes the revised plan; originals untouched.

*Teaching point: in Plan mode the plan is the steering wheel — on tasks that change files, reviewing the whole plan before approving is what keeps you safe.*
---

## 3.16 — The agentic loop: the reframe, now that they've seen it

### The reframe, now that they've seen it
Now the contrast lands — the room has just watched delegation happen, so the comparison is concrete, not abstract:

| | Chatting | Delegating to an agent |
|---|---|---|
| **How you work** | One message at a time | Describe an outcome |
| **Steps** | You do each one | It plans and executes them |
| **Output** | Text in the window | Files on your disk |
| **Your role** | Type the next prompt | Read the plan, steer mid-task |

*Note: "chatting" and "delegating" are two ways of working — not two products. You can chat in the Cowork tab and delegate from the Chat tab. The difference is the mode, not the surface.*
---

## 3.17 — The agentic loop: where it lives

### File structure
```
GLOBAL — session and history artefacts
~/.claude/
└── projects/
    └── <project-hash>/
        ├── memory/ ← auto memory (persists across sessions)
        └── history/ ← compacted conversation summaries

LOCAL — no dedicated local files for the loop itself
<project-root>/
├── CLAUDE.md ← instructions that shape the plan
└── .claude/
    └── skills/ ← skills loaded into each session
```
> The plan itself exists only in the session context window — it is not saved to disk. Use `/branch` to checkpoint, `/rewind` to roll back.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✗ | ✓ | ✓ | ✗ |
*The loop runs on both Code and Cowork. What differs is the checkpoint style: Code adds Plan mode (one up-front plan); Cowork uses per-action approval (see slide 3.19). Web / Chat: single-turn responses only, no multi-step file execution. Studio: conversational only, not agentic.*
---

## 3.18 — The agentic loop: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Read the plan carefully before approving — it's the steering wheel | Auto-approve without reading; plan errors compound through execution |
| Use redirect mid-task to course-correct early | Wait until the end to flag a wrong direction — backtrack is expensive |
| Save a restore point before a risky approach — so you can undo cleanly | Start a long task with no way back — set a checkpoint first |
| Write specific outcome descriptions — the plan quality reflects the prompt quality | Give vague goals ("improve this") — the agent interprets, often incorrectly |
| On a long session, free up room before it fills — don't wait | Let the session overflow unmanaged — trimming mid-task loses nuance |

### Controlling the loop — the Code-tab commands
| What you want to do | Command |
|---|---|
| Review the full plan before it acts | `/plan` (Plan mode) |
| Undo — the agent went the wrong way | `/rewind` |
| Try a different approach without losing your work | `/branch` (also `/fork`) |
| Free up room in a long session | `/compact` |
| Start fresh | `/clear` |
| Check how full the session is | `/context` |

### For power users
A few more live only in the terminal: `/resume` / `/continue` (pick up a past session), `/checkpoint` (mark a restore point), `/btw` (a side question that never enters the main thread). Mention they exist, move on.

---
---

## 3.19 — Cowork: how approval works

**Tag:** Foundation · Cowork

**Headline:** Cowork — the same loop, a simpler approval model

Cowork runs the same agentic engine as Claude Code, but with **no Plan mode and no terminal**. Instead of one consolidated up-front plan, you control it with a single two-way switch.

### The mode selector — two options (the "Ask ∨" dropdown)
| Mode | What Claude does | Use it when |
|---|---|---|
| **Ask before acting** *(default)* | Pauses and asks before **each action** it takes on your behalf — editing a file, running a command, using a connector, opening an app | New tools, unfamiliar files, anything you want to watch closely |
| **Act without asking** | Works straight through without pausing — faster, riskier | Well-defined tasks you trust, while you're actively supervising |

> **Two things are always true, in either mode:**
> - Claude **always asks before permanently deleting** a file.
> - Claude **always asks before using a new app** on your computer (computer use is prompted per-app; some apps — trading, crypto — are blocked by default).

### What "each action" means
The pause is for things Claude *does*, not things it reads. Reading files in a folder you already granted just proceeds. The approval prompt appears when it's about to **change something or reach outside** — write, move, run, connect, click.

### Example to cover
**Setup:** A messy folder (~10 mixed files). Leave Cowork in its default **Ask before acting** mode.

> *"Rename every file to `YYYY-MM-DD_description`, sort into subfolders by type, and write an index file."*

→ Claude proposes the first change and **pauses**. You approve — or redirect: *"copy, don't move the originals."* It continues, asking before each consequential step. Nothing is renamed, moved, or deleted without your say-so.

*Teaching point: Cowork doesn't give you one big plan to approve — it asks as it goes. That's the knowledge-work version of the loop: review each step, steer any time.*

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Start in **Ask before acting** until you trust a workflow | Switch to "Act without asking" on unfamiliar files or untrusted sites |
| Watch the per-action prompts — they're your steering points | Click approve reflexively; read what each step will change |
| Keep a dedicated working folder so you know what's in scope | Grant a folder with confidential data or credentials |
| Use "Act without asking" only while actively supervising a trusted, well-defined task | Walk away with "Act without asking" on |

### Related
*Cowork is GUI-only — no slash commands. Control is the mode dropdown, the per-action approve/redirect prompts, and the folder picker. For a hard, un-talk-around-able block (e.g. /confidential/), you'd need Claude Code's configuration-level enforcement — Cowork can only ask, not hard-block.*

---

## 3.20 — Section 3 mission: build your Claude Code workspace

**Tag:** Foundation · Claude Code · hands-on mission

**Headline:** Put all four foundations to work in one task

**The brief:** Set up Claude Code to help with a small pile of documents. By the end you'll have a workspace that knows your rules, works on your files safely, remembers your preferences, and executes a multi-step job under your control — using every Foundation concept once.

**Setup (2 min):** Make a folder `~/workspace-demo/` with ~6–10 mixed files (any PDFs or documents — messy names are good). Open Claude Code in that folder.

### The mission — four linked tasks
| # | Do this | Foundation concept | The move |
|---|---|---|---|
| 1 | Run `/init`, then edit `CLAUDE.md`: add your tone, house style, preferred terms, and a hard rule "never touch files outside this folder" | Persistent instructions (3.1) | Write the behavioral contract |
| 2 | Ask Claude to read a file on your Desktop (outside the folder) — watch it refuse | Working directory + permissions (3.9) | Verify the boundary holds |
| 3 | Enter Plan mode (`/plan`): *"rename files to `YYYY-MM-DD_title`, sort into subfolders by type, write `index.md`."* Read the plan, redirect once — *"copy, don't move the originals"* — then approve | The agentic loop (3.14) | Read the plan, steer, approve |
| 4 | Mid-session, correct a preference: *"always list newest first."* Start a **new** session, ask for the index again — confirm it remembered | Auto memory (3.5) | Let it learn across sessions |

### Done when
- `CLAUDE.md` exists and carries your rules (incl. the out-of-folder hard stop)
- Claude **refused** the out-of-scope file in task 2
- A `/sorted` folder + `index.md` exist; the originals are untouched
- The new session honoured your "newest first" correction without being re-told

### Deliverables to hand in
Your `CLAUDE.md`, a screenshot of the refusal, the reorganised folder + `index.md`, and proof the second session remembered.

### Stretch
Add a second project rule and show it changes the next output · use `/rewind` to undo a wrong approval · re-run the same job in Cowork (Ask before acting) and compare how the approval *feels* vs Plan mode.

> **Debrief for the room:** which foundation did the most work here — the instructions, the permission boundary, the plan, or the memory? Surfaces how each person thinks about staying in control.

---

# Section 4 — Agent capabilities

*What you create once and reuse across tasks.*
---

## 4.1 — Skills: what it is

**Tag:** Agent capabilities

**Headline:** Skills — encode a workflow once

### Structure
- Folder + `SKILL.md` with YAML frontmatter (name + description)
- Optional reference files and scripts alongside
- Description drives triggering — semantic, not keyword
- One job per skill. If you write "and also", split it.
- Lives in `.claude/skills/` (Code) or Settings (Cowork/claude.ai)

### Use case
> A "doc-summary" skill formats any document into the team's 5-section template — consistently, for everyone who installs it.
---

## 4.2 — Skills: demo

### Example to cover
```markdown
---
name: doc-summary
description: Use when the user shares a document or link and wants the team's structured summary.
---
Summarize into: Purpose / Key points / Decisions / Risks / Next steps.
2-3 sentences each. Note owner and due date under Next steps.
```
*Run two documents through it. Show consistency. Then try a vague description — show why it matters.*
---

## 4.3 — Skills: one with parameters & logic

**Headline:** A skill isn't just a template — it takes arguments and branches

Skills carry logic two ways: **conditional instructions** in the SKILL.md, and an optional **bundled script** that does real computation. Here's one `digest` skill that does both — it summarises the files in a folder over a time window you choose.

### The SKILL.md
```markdown
---
name: digest
description: Summarise files in a folder over a time window. Use when the user says "digest" or asks for a recent-changes summary. Takes a window and an output format.
---

# Digest

Arguments (all optional):
- `--since <N>`  → only files changed in the last N days. Default: 7.
- `--format <bullets|table|prose>`  → output shape. Default: bullets.

## Steps
1. Get the files in range:  !`python scripts/recent.py --since {{since|7}}`
2. If the script returns an empty list, reply exactly:
   "Nothing changed in the last N days." — do not invent entries.
3. Otherwise summarise each file in one line, then render in the chosen format:
   - bullets → a "- " list, newest first
   - table   → columns: file · date · one-line summary
   - prose   → one 2–3 sentence paragraph, no list
4. Always end with a count: "N files · last N days."
```

### The bundled script (the real logic)
```python
# scripts/recent.py
import argparse, os, time, json
ap = argparse.ArgumentParser()
ap.add_argument("--since", type=int, default=7)
cutoff = time.time() - ap.parse_args().since * 86400
hits = [{"file": f, "mtime": os.path.getmtime(f)}
        for f in os.listdir(".")
        if os.path.isfile(f) and os.path.getmtime(f) >= cutoff]
hits.sort(key=lambda x: x["mtime"], reverse=True)
print(json.dumps(hits))
```

### Run it three ways
```bash
/digest                          # defaults: last 7 days, bullets
/digest --since 30 --format table
/digest --since 1 --format prose
```

*Teaching point: the `--since` default, the empty-list guard, and the format branch are all **logic** — the skill decides what to do, it doesn't just paste text. The script handles the part Claude shouldn't eyeball (date math); the SKILL.md handles the judgement (how to summarise, what to do when there's nothing).*

---

## 4.4 — Skills: the Vercel skills library

### Vercel skills library
```bash
npx skills add vercel-labs/agent-skills --list # browse
npx skills add vercel-labs/agent-skills --skill frontend-design -a claude-code
```
`skills.sh` — community directory + leaderboard.
*Caveat: mostly developer-focused. Code-side. Vet before installing.*
---

## 4.5 — Skills: where it lives

### File structure
```
USER-LEVEL — available everywhere; loaded by BOTH Code and Cowork
~/.claude/
└── skills/
    └── doc-summary/ ← one folder per skill
        ├── SKILL.md ← required: name, description, instructions
        └── template.md ← optional reference file
    (Cowork surfaces these via Customize → Skills / the directory)

PROJECT-LEVEL — committed with the repo; loaded by CLAUDE CODE ONLY
<project-root>/.claude/
└── skills/
    └── data-cleaner/
        ├── SKILL.md
        └── cleaning-script.py ← optional executable script
    ⚠️ Cowork does NOT scan a project's .claude/skills/ — see note below

LEGACY (still work, now merged with skills)
~/.claude/commands/doc-summary.md ← global command
<project-root>/.claude/commands/clean.md ← local command

VERCEL CLI INSTALL
.agents/skills/<name>/SKILL.md ← installed here, symlinked into .claude/skills/
```
> If a skill and a command share the same name, the skill takes precedence.
>
> **Important for Cowork:** project-directory skills (`<project-root>/.claude/skills/`) are a **Claude Code** mechanism — Code scans the working directory + parents up to the repo root at session start. **Cowork does not load project-directory skills.** To use a skill in Cowork, install it as a user-level skill (Customize → Skills / the directory) or ship it inside a plugin. Plugin-provided skills work in both Chat and Cowork.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ⚠️ | ✓ | ✓ | ✗ |
*Code: both user-level and project-level `.claude/skills/` + Vercel CLI. Cowork: user-level skills only (Customize → Skills) + plugin-provided skills — **not** project-directory skills. Web / Chat (claude.ai): user-level skills via Settings + plugins, same SKILL.md format, no CLI. Studio: no skills support.*
---

## 4.6 — Skills: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| One skill, one job — if you write "and also", split it into two skills | Write a skill that does multiple unrelated things — it misfires and is hard to debug |
| Make the description precise and semantic — it's the trigger | Use vague descriptions like "help with documents" — too broad to activate correctly |
| Test with at least 3 different inputs to verify consistency | Assume it works after one test — edge cases break broad skills |
| Version-control your SKILL.md files alongside your project code | Install community skills without reading the SKILL.md first |
| Share team skills via a plugin so everyone gets the same version | Duplicate skills across machines manually — use the Vercel CLI or a plugin |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/skills` | Code | List skills loaded in the session. *(The command is CLI-only; in Chat/Cowork you manage skills via Settings — see the Skills availability matrix.)* |
| `/reload-skills` | Code | Reload skills from disk without restarting Claude Code. Useful after editing a SKILL.md. |

---
---

## 4.7 — Subagents: what it is

**Tag:** Agent capabilities

**Headline:** Subagents — delegate to a specialist

### Structure
- Isolated assistant with its own context, instructions, tool access
- Returns one summary — keeps the main thread clean
- Built-ins: Explore · Plan · General-purpose
- Custom ones: `/agents` → markdown + YAML → `.claude/agents/`
- Caveat: auto-delegation unreliable — explicit invocation is dependable

> **Built on top of the agentic loop (→ Slide 3.14), not a replacement for it.** Each subagent runs its own internal agentic loop. The difference is who coordinates: in the agentic loop you steer one agent; with subagents a parent agent (or the orchestration script in dynamic workflows) spawns and collects from multiple isolated agents. Use subagents when the task benefits from parallelism, specialist context isolation, or keeping the main thread clean.

### Use case
> A fact-checker subagent re-verifies every figure in a report while the main thread keeps drafting the summary.
---

## 4.8 — Subagents: demo

### Example to cover
**The point of subagents: run several specialists at once, each in its own context, and get back clean summaries — not raw transcripts.**

**Scenario:** You have a folder of 8 vendor proposals and want them reviewed three ways. Done in one thread, the context fills with everything; done with subagents, three specialists work in parallel and report back.

**One prompt, three delegations:**
> *"For the proposals in this folder, run three reviewers in parallel: one extracts pricing and contract terms, one flags risk and compliance issues, one scores each against our requirements checklist. Give me a combined table."*

**What happens:**
```
        ┌─ terms-extractor   → reads all 8, returns: price, term, SLA
main ───┼─ risk-screener     → reads all 8, returns: risk-flag list
 (you)  └─ scorer            → reads all 8, returns: score + reason vs checklist
            │
            ▼
     main thread merges 3 summaries → one table; your context stays clean
```

**Why this needs subagents, not one thread:**
- **Parallel** — three reads happen at once, not sequentially
- **Isolated context** — each reviewer only carries its own job; the risk screener isn't distracted by the requirements checklist
- **Clean main thread** — you get three tidy summaries back, not 24 pages of intermediate reasoning

**What one reviewer actually is — the full file.** A custom subagent is a single markdown file in `.claude/agents/` (project) or `~/.claude/agents/` (user). The YAML frontmatter configures it; the body is its system prompt:

```markdown
---
name: risk-screener
description: Reviews vendor proposals for risk and compliance issues. Use when
  the user asks to screen, vet, or flag risks in one or more proposals.
tools: Read, Grep, Glob          # read-only — it can't modify files
model: sonnet                    # cheaper than Opus; fine for screening
---
You are a procurement risk analyst.

## Inputs (passed in the invocation message)
- `folder`             — path to the proposals folder (required)
- `severity-threshold` — minimum severity to report: HIGH | MEDIUM | LOW (default: MEDIUM)
- `categories`         — comma-separated filter, e.g. "liability,SLA" (default: all)

## Steps
For each proposal file in `folder`:
1. Read the full document.
2. Flag issues across: liability · data/security · termination ·
   pricing escalation · SLA gaps · regulatory/compliance.
   Skip categories not in `categories` if a filter was given.
3. Only report issues at or above `severity-threshold`.
4. Cite the exact clause or line each issue comes from.

## Output
Return ONLY a markdown table — no preamble, no summary:
| Proposal | Category | Severity | Clause | Note (one line) |
Do not add commentary outside the table.
```

Only `name` and `description` are required frontmatter. **Subagents have no `params:` field** — unlike skills (which use `{{param|default}}` template syntax), parameters are passed through the invocation message itself and documented in the system prompt body. The agent reads them as instructions, applies defaults when they're absent, and the system prompt is the parameter contract.

### How do you actually call an agent?
Three ways:

| Method | How | When it fires |
|---|---|---|
| **Automatic** | Claude reads each agent's `description` and delegates when a request matches | Convenient, but **unreliable** — don't depend on it |
| **Explicit, by name** | *"Use the **risk-screener** subagent on the proposals in this folder."* | The dependable way — say "use the X subagent" |
| **Explicit, with params** | *"Use the **risk-screener** subagent: folder=./proposals severity-threshold=HIGH categories=liability,SLA"* | Pass params inline in the invocation message |
| **Explicit, @-mention** | `@risk-screener folder=./proposals severity-threshold=MEDIUM` | Quick inline trigger in the Code tab |

*(For a whole session pinned to one agent, launch with `claude --agent risk-screener`. To create or edit agents in a GUI, run `/agents`.)*

> **Can you call an agent directly with `/`?** No — the `/` system belongs to skills (and the legacy `.claude/commands/` directory). Agents don't register a slash command of their own. The workaround: write a thin skill that invokes the agent, and call *that* with `/risk-screen`. This also lets you chain multiple agents behind one slash command — the skill acts as an orchestration layer.

So the parallel demo above is really:
> *"Use the **terms-extractor**, **risk-screener** (severity-threshold=HIGH), and **scorer** subagents on ./proposals; give me a combined table."*

Three named invocations in one prompt, each receiving their own parameters.

### Calling risk-screener — concrete examples

**Simplest call — all defaults (MEDIUM+, all categories):**
```
Use the risk-screener subagent: folder=./proposals
```

**Raise the bar — HIGH issues only, two categories:**
```
Use the risk-screener subagent:
  folder=./proposals
  severity-threshold=HIGH
  categories=liability,data/security
```

**@-mention shorthand in the Code tab:**
```
@risk-screener folder=./proposals severity-threshold=HIGH
```

**What comes back** (the agent returns only this table — no preamble):
```
| Proposal          | Category      | Severity | Clause      | Note                                     |
|-------------------|---------------|----------|-------------|------------------------------------------|
| acme-proposal.pdf | liability     | HIGH     | §8.2        | Uncapped liability on service failures   |
| acme-proposal.pdf | data/security | HIGH     | §12.1       | No mention of encryption at rest         |
| beta-corp.pdf     | SLA gaps      | MEDIUM   | §5, §6      | Uptime SLA missing for EU region         |
```
*If no issues meet the threshold, the agent replies: "No issues at or above HIGH found across N proposals." — it never invents rows.*

*Teaching point: reach for subagents when a task splits into independent parts that each need focus — parallel work, specialist isolation, or keeping the main conversation uncluttered. If it's one linear job, you don't need them. And name them explicitly — auto-delegation is too flaky to rely on.*
---

## 4.9 — Skills vs Subagents: which one?

**Headline:** They look identical on disk — they do opposite jobs

Both are a folder with a markdown + YAML file, so they get confused constantly. The difference isn't the file — it's **where the work runs**. A skill runs *inside* your conversation; a subagent runs *beside* it.

| | **Skill** | **Subagent** |
|---|---|---|
| **What it is** | Reusable instructions (+ optional scripts) the main agent loads | A separate agent the main one delegates a job to |
| **Where it runs** | *Inside* your current thread — in front of you | *Beside* it — its own context window, own tools |
| **Effect** | Changes **how the main agent behaves** for this task | Offloads a whole sub-task and **returns a summary** |
| **Context** | Shares your context — you see every step | Isolated — you get the result, not the transcript |
| **Parallel?** | No — one inline task at a time | Yes — several can run at once |
| **Cost when idle** | ~tiny (≈100 tokens until triggered) | None until invoked; heavier once running |
| **Triggering** | Auto-loaded when your request matches its description | Reliable only when you name it explicitly |
| **Lives in** | `.claude/skills/<name>/SKILL.md` | `.claude/agents/<name>.md` |

### The one-line rule
> **Small, and should stay in front of you → Skill.** *(format a citation, follow a house style, run a fixed procedure)*
> **Big or noisy, and should run in a side process → Subagent.** *(review 8 proposals in parallel, search a whole folder, run a long check without cluttering the thread)*

### They compose
A subagent can *use* skills inside its own context — e.g. a `terms-extractor` subagent that loads your `extraction-format` skill. Skills are the *how*; subagents are the *who*. Reach for a subagent only when isolation or parallelism earns its keep — otherwise a skill is simpler.

---

## 4.10 — Subagents: where it lives

### File structure
```
GLOBAL — available in every project
~/.claude/
└── agents/
    └── fact-checker.md ← agent definition (name, description, system prompt, tools)

LOCAL — available in this project only
<project-root>/.claude/
└── agents/
    └── terms-reviewer.md

PLUGIN-PROVIDED — bundled with a plugin install
<plugin-root>/
└── agents/
    └── data-analyst.md ← auto-discovered when plugin is loaded
```
> Agent files use the same YAML frontmatter format as skills: `name`, `description`, `model`, `tools`.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✗ | ✓ | ⚠️ | ✗ |
*Code: full subagent configuration via `/agents` + `.claude/agents/` markdown files. Cowork: subagents coordinated under the hood — no manual `/agents` config exposed in the GUI. Web / Chat & Studio: no subagents.*
---

## 4.11 — Subagents: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Invoke subagents explicitly — don't rely on auto-delegation | Assume Claude will automatically route to your custom subagent — it often won't |
| Give each subagent a narrow, single responsibility | Build one subagent that does research, writing, and fact-checking — it loses focus |
| Ask the subagent to update its memory after completing a task | Give a subagent access to more tools than its job requires |
| Use a read-only subagent (e.g. **Explore**) for "go find and summarise" jobs — searching docs, scanning a folder, pulling facts | Use Opus for every subagent — Sonnet or Haiku handles most sub-tasks at lower cost |
| Review the single summary the subagent returns — don't trust it blindly | Expect a subagent to spawn its own subagents — nesting is one level deep only |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/agents` | Code | Open the agent manager — create, edit, configure custom subagents. |

---
---

## 4.12 — Section 4 mission: build two specialists

**Tag:** Agent capabilities · Claude Code · hands-on mission

**Headline:** One skill, one subagent, both invoked — 15 minutes

**The brief:** Build a skill that formats meeting notes and a subagent that screens documents for action items. Run them both explicitly. By the end you'll have two reusable specialists you can keep.

**Setup (1 min):** Create a folder `~/specialists-demo/` with 3–4 short plain-text documents (any emails, notes, or reports — paste some real content or invent it). Open Claude Code in that folder.

### The mission — three linked tasks

| # | Do this | Concept | The move |
|---|---|---|---|
| 1 | Create `~/.claude/skills/meeting-notes/SKILL.md` with a `--format` parameter (bullets \| action-items, default: bullets) and a no-input guard. Ask Claude to summarise a document — watch the skill auto-load. | Skills (4.1–4.3) | Write the skill; verify auto-triggering |
| 2 | Create `.claude/agents/action-screener.md` with `folder` and `priority` parameters (HIGH \| MEDIUM \| LOW, default: MEDIUM). Give it read-only tools. | Subagents (4.7–4.8) | Write the agent file; set the parameter contract |
| 3 | Invoke both explicitly in one session: *"Use the **action-screener** subagent: folder=./  priority=HIGH"* then *"/meeting-notes --format action-items"* on the result. Confirm the subagent's table and the skill's formatted output are different artefacts. | Skills vs Subagents (4.9) | Feel the difference: inline vs isolated |

### The files you'll write

*Part of the mission is figuring out what goes in each file — don't copy a solution, write it from scratch using slides 4.1–4.8 as your reference.*

**`~/.claude/skills/meeting-notes/SKILL.md`** (user-level):
Required: correct frontmatter · a `--format` parameter with a default · a no-input guard · clear output instructions for each format variant.

**`.claude/agents/action-screener.md`** (project-level):
Required: correct frontmatter · read-only tools · `folder` and `priority` parameters with defaults documented in the body · a strict output format (table only, no preamble) · a no-results guard.

### Done when
- `/meeting-notes --format action-items` produces a formatted table from a document
- `@action-screener folder=./ priority=HIGH` returns a cross-file action table (or the no-items message)
- The two outputs are visibly different — the skill ran inline, the subagent returned a summary

### Deliverables to hand in
Both files, a screenshot of the skill being auto-triggered, and a screenshot of the explicit subagent invocation with its output.

### Stretch
Add a second parameter to the skill (`--owner <name>` — filter the action-items table to one owner) · call the subagent with `priority=LOW` and compare the output length · run `/meeting-notes` on the subagent's output to format its table into bullets.

> **Debrief for the room:** when did you reach for the skill vs the subagent? Did the isolation of the subagent feel useful — or overkill for this task? That tension is the whole point of slide 4.9.

---

# Section 5 — Integration & output

*How the agent reaches outside itself and produces things: connectors to external systems, plugin bundles, and rendered artifacts.*

## 5.1 — Connectors (MCP): what it is

**Tag:** Integration & output

**Headline:** Connectors — reach beyond the session

### Structure
- Model Context Protocol — standardised connection to external systems
- Google Drive · Gmail · Zoom · Slack · databases · APIs
- Installed per connector; combinable
- The "hands" — what the agent can touch that it otherwise cannot

### Use case
> You have 40 files in a Google Drive "Q3 Planning" folder. Without MCP: download → upload to chat → paste. With Drive MCP: one prompt, Claude reads the folder directly and returns a structured summary.
---

## 5.2 — Connectors (MCP): demo

### Example to cover — Google Drive (most used for knowledge workers)

**Step 1 — Install (2 min):**
```
/mcp install google-drive@claude-plugins-official
```
Follow the OAuth prompt. Grant read access to the Q3 Planning folder only — not the whole Drive.

**Step 2 — Run a real task:**
> *"Search my 'Q3 Planning' Drive folder for files from 2025–2026. For each: title, owner, type, key takeaway. Sort by date."*

→ Claude reads directly — no upload, no copy-paste. Show the time difference vs. the manual route.

**Step 3 — Show the permission boundary:**
> *"Now search the 'HR / Compensation' folder."*
→ Claude refuses — that folder was never granted. The permission model working as a guardrail.
---

## 5.3 — Connectors (MCP): most-used MCP servers

### Most used MCP servers — ranked for knowledge workers
| Server | Best for |
|---|---|
| **Google Drive** *(most accessible)* | Documents, spreadsheets, shared folders — no coding needed |
| **Gmail** | Inbox triage, drafting replies, pulling thread context |
| **Slack** | Channel summaries, catching up on meeting context |
| **Brave / web search** | Real-time info beyond Claude's knowledge cutoff |
| **GitHub** *(technical teams)* | Issues, pull requests, version control, code review |

> Start with **one** — the connector that closes your biggest workflow gap. Adding too many fills context faster than expected.
---

## 5.4 — Connectors (MCP): the range is wider than you think

**Headline:** Any app that exposes an MCP server becomes something you can talk to

MCP isn't only for productivity tools. The same connector mechanism that links Claude to your Drive or inbox also links it to design tools, deployment platforms, scheduling systems, and even game engines. A few cases that show the range:

| Platform | What it exposes | What you can do |
|---|---|---|
| **Figma** | Design files, components, variables, layout data, design tokens | *"Implement this screen from the Figma link — use our existing component library."* Claude reads the live design spec and generates code that matches your actual codebase, not a screenshot guess. Also works in reverse: push code back to canvas. |
| **Vercel** | Projects, deployments, runtime logs, domains, env vars | *"My last deployment failed — what's in the logs?"* Claude fetches the build log, reads the error, and proposes a fix — without leaving your editor. |
| **Cal.com** | Availability slots, event types, bookings, schedules | *"Book the first available 30-min slot next week for Ana and reschedule Thursday's call to Friday."* Claude checks real availability and creates the booking — 34 tools, no calendar ping-pong. |
| **Home Assistant** | Every smart device, automation, area, and energy state | *"Turn off everything in the office, set the thermostat to 20°C, and tell me which devices have been on for more than 6 hours."* 86+ tools over a WebSocket to your local instance. |
| **Roblox Studio** | Scripts, terrain, lighting, instances, animation, sound, particles | *"Add a day/night cycle, make the terrain hillier around the north edge, and write the Lua script for the door trigger."* 96+ tools — Claude edits a live game world by chat. |

> **The pattern in all five:** the platform opened its own internals as MCP tools. Claude didn't get a new capability — the *platform* became conversational. Any system with an API can do the same thing.

*Install: each has an official MCP server. Add via `/mcp install <server>` in Code, or the Connectors UI in Chat/Cowork. Figma, Vercel, and Cal.com are remote (OAuth). Home Assistant and Roblox run locally.*

---

## 5.5 — Connectors (MCP): building your own server

### Building your own (for technical teams)
Using the `mcp-builder` skill + Claude Code, build a server wrapping any internal API in one session:
```bash
npx skills add vercel-labs/agent-skills --skill mcp-builder -a claude-code
# Then ask Claude Code:
"Build an MCP server wrapping our internal CRM API.
 Expose three tools: search_accounts, get_account, list_open_deals."
```
---

## 5.6 — Connectors (MCP): where it lives

### File structure
```
GLOBAL — user-level MCP servers (all projects)
~/.claude/
└── mcp.json ← user-level server list

LOCAL — project-level MCP servers (this project only)
<project-root>/
└── .mcp.json ← project server list (committed to repo = shared with team)

PLUGIN-PROVIDED — bundled MCP config
<plugin-root>/
└── .mcp.json ← pre-wired servers that activate on plugin install

EXAMPLE .mcp.json
{
  "mcpServers": {
    "google-drive": {
      "command": "npx", "args": ["-y", "@anthropic-ai/mcp-server-gdrive"]
    }
  }
}
```
> Web and Cowork connectors are configured via the Settings UI — no local file to edit.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✓ | ✓ | ✓ | ✗ |
*Web / Chat, Code & Cowork: full MCP connector support (Drive, Gmail, Zoom, Slack, etc.). Studio: no MCP support.*
---

## 5.7 — Connectors (MCP): do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Use connectors for non-sensitive, non-regulated data sources | Connect to systems holding PII or regulated data without compliance review |
| Review what each connector can read and write before installing | Install MCP servers from untrusted sources without reading their documentation |
| Combine connectors deliberately (Drive + Gmail + Slack for a reporting workflow) | Grant write access to a connector unless the task explicitly needs it |
| Check for data freshness — connectors pull live data but sources can lag | Assume the data pulled is always current — verify timestamps on critical information |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/mcp` | Code · Cowork | Open the MCP manager — add, remove, configure MCP server connections. |

---
---

## 5.8 — Plugins: what it is

**Tag:** Integration & output

**Headline:** Plugins — ship the whole thing

### Structure
Distribution unit for a full workflow — bundle skills + agents + hooks + MCP in one install:
```
team-starter-plugin/
├── .claude-plugin/
│ └── plugin.json ← name, version, description
├── skills/
├── agents/
├── hooks/
└── .mcp.json
```

### Use case
> A team lead ships one plugin to every new hire. From day one: house-style skill, fact-checker, confidential-data-guard hook, Drive connector — zero setup.
---

## 5.9 — Plugins: demo

### Example to cover
```bash
/plugin install anthropics/knowledge-work-plugins
```
→ Show what arrives. Then build a minimal 3-file team starter plugin live.

**Official libraries:**
- `anthropics/claude-plugins-official` — Anthropic managed directory
- `anthropics/knowledge-work-plugins` — 11 production plugins
---

## 5.10 — Plugins: where to find them

**Headline:** You don't have to build one — most workflows are already in a marketplace

### Anthropic official — `anthropics/claude-plugins-official`
The canonical starting point. Managed directly by Anthropic, pre-loaded in every Claude Code install.

| What's in it | Details |
|---|---|
| **Size** | 55+ curated plugins (growing) |
| **Structure** | `/plugins` — Anthropic-built · `/external_plugins` — vetted partners |
| **Categories** | Code intelligence (LSP for 10+ languages) · External integrations (pre-wired MCP servers) · Dev workflow (git, PR review, plugin dev tools) |
| **Browse** | `claude.com/plugins` or `/plugin` → Discover tab (already in your install) |
| **Install** | `/plugin install <name>@claude-plugins-official` |

> ⚠️ Anthropic curates the list but does not control what MCP servers or scripts a plugin ships — always check the plugin's homepage before installing.

### Community marketplaces worth knowing

| Marketplace | What it is | Add it |
|---|---|---|
| **wshobson/agents** | Multi-harness (Claude, Codex, Cursor, Gemini CLI). Multi-agent orchestration with a 3-tier model strategy: Opus for critical tasks, Sonnet for complex work, Haiku for speed | `/plugin marketplace add wshobson/agents` |
| **jeremylongshore/claude-code-plugins-plus-skills** | 425 plugins · 2,810 skills · 200 agents. Has its own CLI package manager (`ccpi`). Browse at `tonsofskills.com` | `/plugin marketplace add jeremylongshore/claude-code-plugins` |
| **hyperskill/claude-code-marketplace** | Education and team focus. Includes a `plugin-development` toolkit for scaffolding, validating, and publishing your own plugins | `/plugin marketplace add hyperskill/claude-code-marketplace` |
| **claudemarketplaces.com** | Third-party aggregator — 200k+ monthly visitors, community voting, updated daily from GitHub. Good for discovering what's trending | browse only (no `/plugin marketplace add`) |

### The mechanics — multiple marketplaces in one install
Claude Code supports multiple active marketplaces simultaneously. The Discover tab shows all of them merged, and install commands route to the right source via the `@marketplace-name` suffix:
```bash
/plugin install python-development@wshobson-agents
/plugin install devops-automation-pack@claude-code-plugins-plus
```

---

## 5.11 — Plugins: where it lives

### File structure
```
PLUGIN SOURCE (the bundle you author or install from)
<plugin-root>/
├── .claude-plugin/
│ └── plugin.json ← manifest: name, version, description (required)
├── skills/
│ └── doc-summary/SKILL.md
├── agents/
│ └── fact-checker.md
├── hooks/
│ └── confidential-guard.json
└── .mcp.json ← pre-wired connectors

INSTALLED via Claude Code (/plugin install) — lands on disk:
GLOBAL → ~/.claude/plugins/<plugin-name>/        (all projects)
PROJECT → <project-root>/.claude/plugins/<name>/ (this repo; Code only)

INSTALLED via Chat / Cowork (GUI directory) — registered to your account,
managed in Customize → Plugins; no project-directory install.
```
> The manifest is optional — Claude auto-discovers components in default locations if `plugin.json` is absent.
>
> **Across surfaces:** the project-directory install (`<project-root>/.claude/plugins/`) is a **Claude Code** path. Chat and Cowork install plugins through the GUI directory to your account — the plugin's skills/agents/MCP then work in those surfaces, but there's no per-project plugin folder. (This is *the* way to get a skill into Cowork — bundle it in a plugin.)

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ⚠️ | ✓ | ✓ | ✗ |
*Code: full plugin manifest (`.claude-plugin/plugin.json`) + `/plugin install` CLI. Cowork: GUI plugin marketplace — install and manage visually, same underlying format. Chat: Skills installable via Settings, but not the full plugin manifest format. Studio: no plugin support.*
---

## 5.12 — Plugins: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Use `anthropics/knowledge-work-plugins` as a starting point — don't build from zero | Install any community plugin without reviewing its `hooks/` — hooks run with your credentials |
| Build a team plugin to ship your entire workflow in one install | Let plugin count grow unchecked — too many skills exceed the context budget and descriptions get truncated |
| Version-control your plugin manifest and components in a shared repo | Share a team plugin externally before scrubbing any internal paths, API keys, or private data |
| Use `/reload-plugins` after editing agents, hooks, or `.mcp.json` (SKILL.md reloads live) | Assume all components reload automatically — only SKILL.md does |
| Bundle the confidential-data-guard hook into your team plugin so it ships to every new member | Publish a plugin to a public marketplace without a security review of its hooks and scripts |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/plugin` | Code · Cowork | Open the plugin manager — browse Discover tab, install, enable/disable plugins. |
| `/plugin install <name>` | Code · Cowork | Install a plugin from a marketplace or local path. |
| `/reload-plugins` | Code | Reload plugin components (agents, hooks, .mcp.json) without restarting. Note: SKILL.md changes reload live; other components need this command. |

---
---

## 5.13 — Artifacts: what it is

**Tag:** Output & sharing · Web · Cowork

**Headline:** Artifacts — where outputs live

### Structure
Artifacts are live, runnable outputs rendered in a side panel. In 2026 there are two tiers:

**Standard Artifacts (all plans)**
- React components · HTML pages · SVG graphics · Mermaid diagrams
- Code snippets · Markdown documents
- Downloadable files: `.docx`, `.pptx`, `.xlsx`, `.pdf`
- Rendered live; iterate through conversation; single-file outputs only

**Advanced Artifacts (paid plans — Pro, Max, Team, Enterprise)**
- **Persistent storage** — up to 20 MB; data survives across sessions via `window.storage` API
- **AI-powered** — artifact calls Claude's own API; Claude runs *inside* the artifact
- **MCP connections** — artifact connects directly to Google Calendar, Gmail, Slack, etc.
- **Live Artifacts** (Cowork) — persistent dashboards that refresh with current data on open; saved in the Cowork "Live artifacts" tab

### Use case
> A team member asks Claude to build an interactive pricing calculator. It renders live in the panel, stores the last quote's inputs in persistent storage, and can be shared with the team via a link — no account needed to view it.
---

## 5.14 — Artifacts: demo

### Example to cover
**Standard artifact — build live in the room:**
*Prompt:* "Build an interactive experiment tracker. Columns: date, condition, n, mean ± SD. Let me add rows. Show a bar chart that updates as I add data."
→ Claude renders a React component. Add rows live. Show the chart updating.
→ Hit **Publish** → copy the link → open in another browser tab (no login). That's sharing.

**Persistent storage — show the difference:**
*Prompt:* "Now make the tracker remember my rows across sessions."
→ Show `window.storage` calls in the code. Close and reopen — data is still there.

**Live Artifact in Cowork:**
*Prompt:* "Build a live dashboard showing our open deals and the team's last 5 closed-won accounts." (with CRM MCP connector)
→ Show the Cowork sidebar "Live artifacts" tab. Reopen next day — data is fresh.
---

## 5.15 — Artifacts: the artifact browser

### Sidebar artifact browser
- All your saved artifacts in one browsable place in the sidebar
- Community catalog — browse and remix published artifacts from other users
- Publish → share via link · anyone can view · logged-in users can remix (get their own editable copy)
---

## 5.16 — Artifacts: where it lives

### File structure
```
ARTIFACTS — cloud-hosted and browser-rendered; no local files by default

Published URL
  https://claude.ai/artifacts/<artifact-id> ← shareable; no account needed to view

Persistent storage — cloud key-value store (paid plans, up to 20 MB per artifact)
  Accessed via window.storage API inside the artifact code
  NOT a local file — managed on Anthropic infrastructure
  ⚠️ Deleted when the artifact is unpublished — export before unpublishing

Live Artifacts in Cowork (April 2026, paid plans)
  Cowork sidebar → "Live artifacts" tab
  Connects to MCP data sources; pulls fresh data on open
  Saved and reusable across sessions

Export to local file
  Download button → .html / .jsx / .svg / .md / .docx / .pptx / .xlsx / .pdf
  Or: ask Cowork to write the artifact output into your local /outputs/ folder
```

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✓ | ⚠️ | ✓ | ⚠️ |
*Web / Chat: full Artifacts in the side panel — all plans; persistent storage and Live features require paid plan. Cowork: full Artifacts + Live Artifacts (paid, April 2026) in the Cowork sidebar. Code: Claude Code writes files to disk — not Artifacts; but you can open Artifacts in the Chat tab alongside Code. Studio (Claude Design): generates visual design artifacts — separate from the code/interactive Artifact system.*
---

## 5.17 — Artifacts: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Enable Artifacts in Settings → Capabilities if the toggle is off | Use `localStorage` or `sessionStorage` — they don't work in artifacts; use `window.storage` instead |
| Use persistent storage for calculators and trackers the team returns to regularly | Put PII or confidential data in persistent storage — it's cloud-stored on Anthropic infrastructure |
| Publish and share via link for team review — recipients need no Claude account | Assume a published artifact stays up forever — export data before unpublishing |
| Use Live Artifacts in Cowork for dashboards needing fresh data (MCP-connected) | Expect multi-file projects — everything must be inlined in one file |
| Download the artifact before unpublishing if you want the code locally | Treat artifacts as a real deployment — they are preview only, not production hosting |

### Related commands
*Artifacts are created through conversation, not slash commands. Key UI actions:*
| UI element | What it does |
|---|---|
| **Artifacts toggle** (Settings → Capabilities) | Enable or disable the Artifacts feature |
| **Publish button** (artifact panel) | Generate a shareable public link |
| **Remix** (published artifact) | Create your own editable copy of someone else's artifact |
| **Sidebar artifact browser** | Browse, organise, and reopen all saved artifacts |
| **Live toggle** (Cowork artifact) | Switch an artifact to Live mode — connects to MCP, refreshes on open |

---
---

# Section 6 — Automation

*What governs and orchestrates the agent — more advanced.*
---

## 6.1 — Scheduled tasks: what it is

**Tag:** Automation · Cowork

**Headline:** Scheduled tasks — set it once, it runs on repeat

Everything so far has been *reactive* — you ask, Claude does. Scheduled tasks make Cowork **proactive**: you describe a job once, pick a cadence, and Claude runs it automatically — delivering a finished output (a brief, a report, a summary) without you starting it each time.

### Structure
- You describe the task once; Claude saves the prompt as the task's instructions
- Pick a cadence: hourly · daily · weekly · weekdays · or **on demand** (manual "Run now")
- Each run spins up its **own fresh Cowork session** and posts a notification when done
- Has the **same powers as a normal Cowork task** — connectors, skills, installed plugins
- Lives in the **Scheduled** tab in the Cowork sidebar — view, edit, pause, see run history
- All paid plans (Pro, Max, Team, Enterprise); Cowork on Claude Desktop

### Use case
> A **daily 8am briefing**: summarise the last 24h of Slack, email, and calendar into one note. A **Friday report**: compile this week's numbers from Drive into a formatted summary. **Recurring research**: track a competitor or topic on a weekly cadence.
---

## 6.2 — Scheduled tasks: demo

### Example to cover
**Build a daily briefing in front of the room.**

**1. Set it up** — two ways:
- In any Cowork task, type **`/schedule`** → describe the cadence in plain language: *"run this every weekday at 8am."*
- Or click **Scheduled** in the sidebar → **New** → fill in the prompt and pick the cadence.

**2. The prompt to save:**
> *"Summarise everything that needs my attention from the last 24 hours: unread Slack mentions, emails marked important, and today's calendar. Group by urgency. Keep it under 200 words."*

**3. Confirm the cadence** — Claude asks to confirm; press enter. The task now appears in the **Scheduled** tab.

**4. Show a past run** — open the task's history: each run is its own session with its own output, ready to review.

*Teaching point: this is the moment Claude stops waiting for you. The same task you'd run manually every morning now arrives finished. Start with one — a morning brief is the classic first routine.*
---

## 6.3 — Scheduled tasks: where it lives & the one big caveat

### Where it lives
```
SCHEDULED TAB — Cowork sidebar
  Lists every scheduled task · cadence · last run · next run
  Per task: edit prompt, change cadence, pause, Run now, view run history

EACH RUN — its own fresh Cowork session
  Uses the connectors, skills, and plugins you've set up in Cowork
  Output saved to the run history + a notification

NO FILE TO EDIT — created via /schedule or the Scheduled tab (GUI only)
```

### ⚠️ The one caveat that trips everyone up
> **Scheduled tasks only run while your computer is awake and Claude Desktop is open.** If the machine is asleep or the app is closed at the scheduled time, the run is **skipped** — then runs automatically once you wake the machine or reopen the app (with a "this was skipped" notification). For runs that must fire even when your computer is off, you need a **cloud routine**, not a local scheduled task.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✗ | ▣ | ✓ | ✗ |
*Cowork: full scheduled tasks via the Scheduled tab / `/schedule`. Code: the same Desktop engine surfaces as **Routines** (local tasks + cloud routines). ▣ = different name, same underlying scheduler. Web / Chat & Studio: not supported.*
---

## 6.4 — Scheduled tasks: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Start with one high-value routine — a morning brief is the classic | Schedule ten tasks before you trust one — review outputs first |
| Write the prompt as if it'll run with no one watching — be explicit about format and length | Assume it'll ask you questions mid-run — it can't; it just executes |
| Connect the tools it needs (Slack, Drive, calendar) in Cowork *before* scheduling | Forget that each run consumes usage — scheduled work is compute-heavy, like any Cowork task |
| Use **on-demand** ("Run now") for prompts you trigger manually but don't want to retype | Rely on it for time-critical runs if your laptop sleeps — use a cloud routine instead |
| Check run history periodically — catch a routine that's drifted or breaking | Leave a broken routine running unattended for weeks |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/schedule` | Cowork | (Skill) Turn the current task into a scheduled task — set cadence or run on demand. |

*Note: scheduled tasks are GUI-first. In the Code tab the same engine appears as **Routines** (sidebar), covering both local tasks and cloud routines.*
---

## 6.5 — Dynamic workflows: what it is

**Tag:** Orchestration at scale

**Headline:** Dynamic workflows — Claude writes its own orchestration

The difference from everything before it comes down to **who holds the plan.** With a single agent you hold it; with a few subagents you coordinate them. With a dynamic workflow, **Claude writes a JavaScript orchestration script on the fly**, runs it in the background, and fans the work out across many parallel subagents — checking its own work before anything reaches you.

### Structure
- Claude writes a JS orchestration script for the task you describe
- A runtime runs it in the background; your session stays responsive
- Fans out across **tens to hundreds** of parallel subagents (up to 1,000 per run, 16 concurrent)
- Built-in verification: results are cross-checked and iterated until they converge
- The plan lives in the script — readable, re-runnable, saveable as a command
- Launched May 2026 (research preview) alongside Opus 4.8; needs Claude Code v2.1.154+

### Use case
> Audit every API endpoint under `src/routes/` for missing auth checks · port a 750k-line codebase from one language to another · find dead code across a huge repo · screen 200 résumés with two independent reviewers each.
---

## 6.6 — Dynamic workflows: how it works

**Headline:** Plan → fan out → refute → converge

The engine isn't just "run subagents in parallel" — it's an **adversarial verification loop** that runs on every subtask:

```
You describe the goal
      │
      ▼
Claude writes a JS orchestration script  ← the plan, as code
      │
      ▼
Script fans work out → N parallel subagents (implementers)
      │
      ▼
A second layer of subagents tries to REFUTE each finding  ← adversarial check
      │
      ▼
Disagreements drive another iteration → results converge
      │
      ▼
Only the verified result reaches you
```

**Why this matters:** the implementer-verifier-verifier-fixer loop runs on every piece of work, in parallel. Each unit gets done, then checked twice by independent agents before it counts. That's what lets a workflow produce something you can trust without reading every intermediate step — the verification is built into the orchestration, not bolted on after.

> The bundled `/deep-research` command is this pattern made concrete: it fans out web searches, cross-checks each source against the others, and applies a survival vote on each claim before producing a cited report.
---

## 6.7 — Dynamic workflows: demo

### Example to cover
**Two ways to trigger it:**
1. Put the word **"workflow"** anywhere in your prompt — Claude highlights it, writes a script, and runs it instead of working in conversation. *(Pressed by accident? `alt+w` ignores the trigger for that prompt.)*
2. Turn on **`ultracode`** (in `/effort`) — Claude then decides *for itself* when a task warrants a workflow.

**The prompt:**
> *"Create a workflow to screen these 200 résumés against: (1) 5+ years experience, (2) project-management background, (3) eligible region. Two independent reviewers per résumé. Flag disagreements. Return a CSV."*

**What to show:**
- Claude surfaces what's about to run and **waits for confirmation** (first workflow in a session always does)
- The script being written, then parallel subagent activity in the agent view
- The verified CSV at the end

**Pair it with Auto mode.** Anthropic's explicit recommendation: turn on Auto mode before a workflow. A run that stops on every permission prompt across hundreds of subagents isn't actually parallel — you'd spend the whole run clicking approve. Auto mode keeps the swarm moving while the safety classifier handles the dangerous calls.

*Hard caveats: Code only. Token-heavy — start scoped.*
---

## 6.8 — Dynamic workflows: when to use it

**Headline:** Subagent → workflow → agent team — pick by the shape of the problem

These three look similar but solve different problems. Using the wrong one wastes tokens and trust.

| | **A few subagents** | **Dynamic workflow** | **Agent team** |
|---|---|---|---|
| **Holds the plan** | You do | Claude (as a script) | The agents, jointly |
| **Scale** | A handful, named explicitly | Tens–hundreds (up to 1,000) | A small fixed crew |
| **Coordination** | You merge their results | The script orchestrates + verifies | Peers talk to each other |
| **Best for** | 2–5 independent specialist tasks | One big task too large for one pass | Tasks where workers must negotiate mid-flight |
| **Reach for it when** | You can name the parts | You can't — there are too many | The parts depend on each other's findings |

> **The one-line rule:** if you can list the handful of jobs yourself → **subagents**. If the task is too big to coordinate in one conversation but the parts are independent → **workflow**. If the parts must talk to each other to make progress → **agent team**.

*CyberAgent's framing: dynamic workflows fill the gap between firing off a single subagent and standing up a full agent team.*
---

## 6.9 — Dynamic workflows: patterns at scale

**Headline:** What "too big for one pass" actually looks like

The résumé-screening demo is the simplest shape. The feature earns its keep on jobs like these:

| Pattern | The job | Why a workflow |
|---|---|---|
| **Codebase audit** | "Find every endpoint missing an auth check across the whole repo" | Hundreds of files, each an independent check, results aggregated |
| **Large migration** | Port / refactor across thousands of files (the Bun team did a 750k-line port this way) | Far more units than one conversation can hold; two reviewers per file |
| **Dead-code discovery** | "Find unused code and cleanup opportunities the linter misses" (Klarna's use) | Cross-file reasoning at a scale static analysis can't reach |
| **Cross-checked research** | "Research X across many sources and give me a cited report" | Fan out searches, refute each source against the others, survival-vote each claim |
| **Bulk document processing** | Classify / extract / score across a large pile of files | Independent per-document work + a verification pass |

> **The common shape:** many independent units of work + a need to verify each one. If your task has that shape and is too big to babysit in one thread, it's a workflow. If it's one linear job, it isn't.
---

## 6.10 — Dynamic workflows: where it lives

### File structure
```
ORCHESTRATION SCRIPT — JS, written by Claude for the task
(runs in the background; you can read it, and save it as a command afterward)

WORKFLOW OUTPUTS — written to the project working directory
<project-root>/
└── outputs/
    └── screening-results.csv ← final verified output

BACKGROUND SESSION STATE — managed by Claude Code's agent view
~/.claude/
└── projects/<project-hash>/
    └── sessions/
        └── workflow-<id>/ ← active run; watch it in the agent view

TRIGGER — no dedicated file
  Prompt: include the word "workflow"   ·   /effort: ultracode
  Disable entirely: CLAUDE_CODE_DISABLE_WORKFLOWS=1
```
> The script is re-runnable — if a run does what you wanted, **save it as a command** and it becomes a repeatable workflow you can invoke again.

### Availability
| Web / Chat | Code | Cowork | Studio |
|:---:|:---:|:---:|:---:|
| ✗ | ✓ | ✗ | ✗ |
*Code only. All **paid** plans (Pro needs it switched on in `/config`; on by default for Max & Team; Enterprise admin toggles it). Also on the API, Bedrock, Vertex AI, and Microsoft Foundry. Research preview as of June 2026. Cowork, Web / Chat, Studio: not supported.*

> **Plan gate softened:** unlike at first launch, dynamic workflows now run on Pro too — but you must enable them in `/config` first. Max and Team have them on by default.
---

## 6.11 — Dynamic workflows: do's, don'ts & commands

### Do and Don'ts
| ✅ Do | ❌ Don't |
|---|---|
| Start with a small, scoped task to learn the token profile before scaling up | Leave `ultracode` on by default — costs compound fast across hundreds of subagents |
| Turn on **Auto mode** before triggering a workflow — Anthropic recommends pairing them | Run with per-action approval on — you'll click approve for the entire run |
| Use it for genuinely parallel, independent work (audits, migrations, multi-reviewer screening) | Use a workflow for a simple sequential task — one agent is faster and cheaper |
| Save a good run as a command so it's repeatable | Re-describe the same big job from scratch every time |
| Read the generated script — the plan is right there, in code | Treat the output as final without spot-checking a sample of decisions |

### Related commands
| Command | Env | What it does |
|---|---|---|
| `/workflows` | Code | View and manage currently running background workflow sessions. |
| `/effort` | Code · Cowork | Set reasoning effort; `ultracode` (Code only) lets Claude auto-decide when to run a workflow. |
| `/deep-research` | Code | Bundled workflow — fans out searches, cross-checks sources, survival-votes each claim, returns a cited report. |
| `/batch <instruction>` | Code | Large-scale parallel changes — decomposes into units, one background agent per unit in an isolated worktree, each opens a PR. |
| `/ultrareview [PR#]` | Code | Parallel multi-agent code review — several specialist subagents review at once. |
---
---

# Section 7 — Synthesis & close

*Tie it together, set the guardrails, send them off.*
---

## 7.1 — Claude Code vs Cowork

**Tag:** Desktop — both live as tabs in the same app
**Headline:** Same engine. Different surface.

*Reference screenshot: `screenshot-cowork-tab.png` (annotated Cowork interface). Pair with `screenshot-chat-tab.png` to show the two surfaces side by side.*

| | Web / Chat | Claude Code | Cowork |
|---|---|---|---|
| **Access** | Browser or app, no install | Desktop app — Code tab + terminal | Desktop app — Cowork tab |
| **Audience** | Everyone | Developers / technical | Knowledge workers, no terminal |
| **Surface** | claude.ai · mobile app | Terminal / CLI + Code tab | Cowork tab — GUI, no terminal |
| **Core job** | Chat, Q&A, one-off tasks | Write, edit, ship code | Multi-step knowledge work on files |
| **Persistent context** | Project instructions + memory | `CLAUDE.md` files | Project context + auto memory |
| **Skills** | User-level via Settings | User + project `.claude/skills/` + Vercel CLI | User-level via Settings + plugins (no project skills) |
| **Subagents** | ✗ | Configured via `/agents` | Under the hood |
| **Plugins** | Skills only via Settings | `/plugin install` + CLI | GUI marketplace |
| **Dynamic workflows** | ✗ | Yes (Max/Team/Ent) | ✗ |
| **Slash commands** | ✗ | Full set (see slides 7.4–7.5) | GUI equivalents |

**Shared:** same agent engine · same files · same skills · same MCP · same plan → approve → redirect loop.

---
---

## 7.2 — Governance & verification

**Headline:** The non-negotiables for work use

- **No PII or confidential data where it shouldn't go.** Nothing regulated, nothing under NDA, into the wrong surface.
- **No audit trail in Cowork.** Not suitable for regulated or sensitive data.
- **Every output is a draft.** Verify figures, quotes, and factual claims against the source.
- **Reproducibility.** Keep prompt + inputs + outputs together — the work must be auditable.
- **Layer your guardrails:** Folder permissions → CLAUDE.md rules → Vetted plugins only → human review.

---
---

## 7.3 — One habit

**Headline:**
> *"Anything you explain to Claude twice is a skill you should write once."*

**Takeaway for the room:**
- Leave today with your starter `CLAUDE.md`
- Leave today with one `SKILL.md` you built in the room
- Both are files — version-control them, share them, improve them

---
---

## 7.4 — Utilities quick reference: session, memory, skills & plugins

**Headline:** Slash commands — the control panel (Claude Code)
*Type `/` to see the full list. `/help` is always the source of truth.*
*Env: **Code** = Code tab only · **Code · Cowork** = Code command with a Cowork GUI equivalent.*

### Session & context
| Command | Env | What it does |
|---|---|---|
| `/clear` | Code · Cowork | Clear conversation history. Start fresh. Aliases: `/reset`, `/new` |
| `/compact [instructions]` | Code | Compress history to a summary. Pass focus instructions to control what's kept. |
| `/context` | Code | Visual grid of context usage + optimisation tips. |
| `/branch [name]` | Code | Fork conversation at this point. Try a risky approach safely. Also `/fork`. |
| `/resume [session]` | Code | Resume a previous session. Also `/continue`. |
| `/rewind` | Code · Cowork | Roll back conversation + file changes to a checkpoint. The undo button. Also `/checkpoint`. |
| `/btw <question>` | Code | Side question — answered in an overlay, never enters the conversation thread. |

### Memory & configuration
| Command | Env | What it does |
|---|---|---|
| `/init` | Code · Cowork | Generate a starter CLAUDE.md from your project. Use `CLAUDE_CODE_NEW_INIT=1` for the full interactive setup (skills, hooks, memory). |
| `/memory` | Code · Cowork | View/edit CLAUDE.md files, toggle auto memory, browse saved entries. |

### Skills & agents
| Command | Env | What it does |
|---|---|---|
| `/skills` | Code | List skills loaded in the session. *(CLI-only command; Chat/Cowork manage skills via Settings.)* |
| `/reload-skills` | Code | Reload skills from disk without restarting. |
| `/agents` | Code | Create, view, and configure custom subagents. |

### Plugins & MCP
| Command | Env | What it does |
|---|---|---|
| `/plugin` | Code · Cowork | Open the plugin manager — browse, install, enable/disable. |
| `/plugin install <name>` | Code · Cowork | Install a plugin from a marketplace or local path. |
| `/reload-plugins` | Code | Reload plugin components (agents, hooks, .mcp.json) without restarting. |
| `/mcp` | Code · Cowork | Add, remove, configure MCP server connections. |
| `/hooks` | Code | View and configure hooks. |
---

## 7.5 — Utilities quick reference: workflows, models, review & utility

### Workflows & automation
| Command | Env | What it does |
|---|---|---|
| `/workflows` | Code | View and manage running background multi-agent workflows. |
| `/batch <instruction>` | Code | (Skill) Decompose a large task into parallel units, spawn one agent per unit. |
| `/loop [interval] [prompt]` | Code | Run a prompt repeatedly on a schedule. Also `/proactive`. |

### Model & performance
| Command | Env | What it does |
|---|---|---|
| `/model [name]` | Code | Switch model mid-session: `/model opus`, `/model sonnet`, `/model haiku`. |
| `/effort [level]` | Code | Control reasoning depth: `low`, `medium`, `high`, `max`, `auto`. |
| `/fast [on\| Code |off]` | Toggle fast mode for quicker responses. |

### Code & review
| Command | Env | What it does |
|---|---|---|
| `/plan [description]` | Code | Enter plan mode — Claude proposes before acting. |
| `/diff` | Code | Interactive diff viewer — git changes and per-turn diffs. |
| `/review [PR]` | Code | Review a PR locally. |
| `/ultrareview [PR#]` | Code | Parallel multi-agent cloud PR review. |
| `/security-review` | Code | Scan current diff for security vulnerabilities. |

### Utility
| Command | Env | What it does |
|---|---|---|
| `/help` | Code | List all commands. Always the source of truth — Anthropic ships updates frequently. |
| `/doctor` | Code | Diagnose installation issues. |
| `/insights` | Code | Analyse your session history and usage patterns. |
| `/voice` | Code · Cowork | Toggle push-to-talk voice dictation. |
| `/ide` | Code | View IDE integration status. |
| `/add-dir <path>` | Code | Add a working directory mid-session. |
| `/extra-usage` | Code · Cowork | Request extra usage when rate-limited. |

---

*End of skeleton — 7 sections, 73 slides.*
